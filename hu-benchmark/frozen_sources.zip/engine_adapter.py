"""Standard heads-up forced-action handling around the vendored engine.

The upstream engine requests redundant actions when only one player has chips
after a matched all-in, and can request action from an all-in blind poster.
Neither condition should query a policy in standard heads-up poker.
"""
from engine.game import PokerEngine as UpstreamPokerEngine


class PokerEngine(UpstreamPokerEngine):
    def start_hand(self):
        state = super().start_hand()
        active = [p for p in self.players if p.is_active]
        if not active or (len(active) == 1 and active[0].bet_this_street >= self.current_bet):
            return self._run_it_out()
        if not self.players[state['seat_to_act']].is_active:
            return self._build_state(active[0].seat)
        return state

    def _advance_street(self):
        if sum(p.is_active for p in self.players) <= 1:
            return self._run_it_out()
        return super()._advance_street()
